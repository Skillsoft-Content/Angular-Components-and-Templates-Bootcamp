This directory/folder is just the app directory/folder

If you want to use this directory/folder, you must have an existing full application

Typically you would start out with the starter application, then move on to Part01, 
then Part02 etc.

So, whichever part you have as a full applicaiton, delete that app folder and replace 
it with this one

Once that step is done, your entire applicaiton is updated

Whenever a file located in the src folder changes, you will see "src" in the title

The same will apply, remove the src folder from the last full build and replace it with 
the current src folder and the applicaiton will be updated
