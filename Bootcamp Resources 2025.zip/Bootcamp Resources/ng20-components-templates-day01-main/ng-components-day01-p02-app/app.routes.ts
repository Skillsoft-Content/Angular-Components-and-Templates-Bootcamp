import { Routes } from '@angular/router';
import { Home } from "./components/home/home";
//
export const routes: Routes = [
  {path:'', component:Home, title: 'Home - Skills20'},
  {path:'home', redirectTo: '', pathMatch: 'full'},
  {path: '**', redirectTo: '', pathMatch: 'full'}

];
