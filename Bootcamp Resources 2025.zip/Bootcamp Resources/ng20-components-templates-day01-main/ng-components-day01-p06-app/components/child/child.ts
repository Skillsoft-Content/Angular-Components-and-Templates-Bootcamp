import { Component, model } from '@angular/core';

@Component({
  selector: 'app-child',
  imports: [],
  templateUrl: './child.html',
  styles: ``,
})
export class Child {
  empNameC = model("");
    onInput(event : Event){
    const empNameValue = (event.target as HTMLInputElement).value;
    this.empNameC.set(empNameValue);
  };

};
