import { Component, model } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Child } from '../child/child';
//
@Component({
  selector: 'app-home',
  standalone:true,
  imports: [FormsModule, Child],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
//
export class Home {
  empNameH = model("Axle");
  fName = "Jane";
};
