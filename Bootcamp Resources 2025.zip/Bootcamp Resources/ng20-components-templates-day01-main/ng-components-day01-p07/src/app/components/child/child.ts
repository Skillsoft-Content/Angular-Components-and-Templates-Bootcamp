import { Component, model } from '@angular/core';

@Component({
  selector: 'app-child',
  imports: [],
  templateUrl: './child.html',
  styles: ``,
})
export class Child {
  empNameC = model("");
    onInput(event : Event){
    const empNameValue = (event.target as HTMLInputElement).value;
    this.empNameC.set(empNameValue);
  };
  logMessage(content: string | null): void {
    if (content) {
      console.log('Content from span:', content.trim());
    }
  };
};
