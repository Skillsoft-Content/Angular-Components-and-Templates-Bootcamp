import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
//
@Component({
  selector: 'app-home',
  standalone:true,
  imports: [FormsModule],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
//
export class Home {
  empName = "Axle";
  fName = "Jane";
  getName(){
    return this.empName;
  };
  isCbChecked = signal(true);
  toggle_CB_State() {
    this.isCbChecked.update(currentValue => !currentValue);
  };

};
