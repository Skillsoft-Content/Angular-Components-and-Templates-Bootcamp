import { Component, effect, ElementRef, model, viewChild } from '@angular/core';
import { Messages } from '../messages/messages';
//
@Component({
  selector: 'app-child',
  imports: [Messages],
  templateUrl: './child.html',
  styles: ``,
})
//
export class Child {
  constructor() {
    effect(() => {
      const messageElement = this.messageField();
      if (messageElement) {
        messageElement.nativeElement.textContent = `Hello, ${this.empNameC()}`;
      }
    });
  };
  empNameC = model("");
  private messageField = viewChild<ElementRef<HTMLSpanElement>>("spanMessage");
  onInput(event : Event){
    const empNameValue = (event.target as HTMLInputElement).value;
    this.empNameC.set(empNameValue);
  };
  logMessage(content: string | null): void {
    if (content) {
      console.log('Content from span:', content.trim());
    }
  };
  onCheckboxChange(event: Event) {
    const checked = (event.target as HTMLInputElement).checked;
    if (checked) {
      console.log('Checkbox is checked');
    };
  };

};
