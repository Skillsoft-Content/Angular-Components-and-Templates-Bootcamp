import { Component, model } from '@angular/core';
//import { FormsModule } from '@angular/forms';
import { Child } from '../child/child';
import { BoldNBlue } from '../../bold-nblue';
//
@Component({
  selector: 'app-home',
  standalone:true,
  imports: [Child, BoldNBlue],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
//
export class Home {
  empNameH = model("Axle");
  fName = "Jane";
};
