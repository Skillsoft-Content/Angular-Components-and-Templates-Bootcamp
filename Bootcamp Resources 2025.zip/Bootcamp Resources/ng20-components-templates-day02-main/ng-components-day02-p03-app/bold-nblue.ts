import { Directive, HostListener, ElementRef, Renderer2  } from '@angular/core';
//
@Directive({
  selector: '[appBoldNBlue]'
})
//
export class BoldNBlue {
  constructor(private el : ElementRef, private render : Renderer2 ) { }
  @HostListener("mouseenter") onMouseEnter() {
    this.render.setStyle(this.el.nativeElement, 'color', 'blue');
    this.render.setStyle(this.el.nativeElement, 'font-weight', 'bold');
  };
  @HostListener("mouseleave") onMouseLeave() {
    this.render.setStyle(this.el.nativeElement, 'color', '');
    this.render.setStyle(this.el.nativeElement, 'font-weight', '');
  };

};
