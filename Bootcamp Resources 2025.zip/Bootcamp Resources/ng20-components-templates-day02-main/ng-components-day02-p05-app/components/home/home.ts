import { Component, model } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Child } from '../child/child';
import { BoldNBlue } from '../../bold-nblue';
import { NaPhNoPipe } from '../../na-ph-no-pipe';
//
@Component({
  selector: 'app-home',
  standalone:true,
  imports: [Child, BoldNBlue, CommonModule, NaPhNoPipe],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
//
export class Home {
  empNameH = model("Axle");
  fName = "Jane";
  currentDate = new Date();
  plainNumber : number = 1234567890;
};
