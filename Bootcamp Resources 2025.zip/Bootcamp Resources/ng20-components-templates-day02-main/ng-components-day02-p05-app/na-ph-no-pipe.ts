import { Pipe, PipeTransform } from '@angular/core';
//
@Pipe({
  name: 'naPhNo'
})
//
export class NaPhNoPipe implements PipeTransform {
  transform(value: string | number, country: string): string {
    if (value === null || value === undefined) {
      return '';
    }
    const strValue = value.toString();
    const cleanValue = strValue.replace(/\D/g, '');
    if (cleanValue.length !== 10) {
      return strValue; 
    };
    const formattedNumber = cleanValue.replace(
      /^(\d{3})(\d{3})(\d{4})$/, 
      '($1) $2-$3'
    );
    if (country === 'S') {
      return cleanValue.replace(
        /^(\d{3})(\d{2})(\d{2})(\d{3})$/,
        '$1 $2 $3 $4'
      );
    };
    return formattedNumber
  };
};
