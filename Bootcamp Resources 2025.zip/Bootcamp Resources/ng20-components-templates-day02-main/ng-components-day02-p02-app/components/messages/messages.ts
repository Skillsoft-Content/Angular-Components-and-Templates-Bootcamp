import { Component } from '@angular/core';
import { ɵEmptyOutletComponent } from "@angular/router";

@Component({
  selector: 'app-messages',
  imports: [ɵEmptyOutletComponent],
  templateUrl: './messages.html',
  styleUrl: './messages.css',
})
export class Messages {

}
